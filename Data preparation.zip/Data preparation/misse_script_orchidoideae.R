########################################################################################################
# Code to run MiSSE on Orchidoideae tree
########################################################################################################

#Set the working directory
setwd("/Users/erichagen1/Desktop/University_of_Toronto_Stuff/publications/orchidoideae")

#Load necessary packages
lapply(c("ape", "hisse"), library, character.only=TRUE)

#Load in the tree
phy <- read.tree("orchidoideae_reltime.tre")

#Generate possible parameter combinations (in total, 30 models for which MiSSE will test fits). We are going 
#to use MiSSEGreedy because that will speed up the analysis on this large Orchidoideae phylogeny.
possible.combos <- generateMiSSEGreedyCombinations(max.param=52, turnover.tries=sequence(10), 
                                                   eps.tries=sequence(3), vary.both=TRUE, fixed.eps.tries=NA)
possible.combos$fixed.eps <- as.numeric(possible.combos$fixed.eps)

samp_frac <- length(phy$tip.label) / 5000

#Run MiSSE. The way this function is currently written requires a machine with 30 cores.
model.set.misse <- MiSSEGreedy(phy=phy, possible.combos=possible.combos, stop.deltaAICc=10, 
                               chunk.size=4, f=samp_frac, root.type = "herr_als", n.cores=30)
save(model.set.misse, file="model_set_misse.Rsave")

#Prune redundant models
model.set.misse <- PruneRedundantModels(model.set.misse)

#Make a folder to store the individual marginal reconstructions
dir.create(file.path(getwd(), "margin_recons"))

#Run marginal reconstructions
model.recons.misse <- as.list(1:length(model.set.misse))
for (model_index in 1:length(model.set.misse)) {
 nturnover <- length(unique(model.set.misse[[model_index]]$turnover))
 neps <- length(unique(model.set.misse[[model_index]]$eps))
 hisse_recon <- MarginReconMiSSE(phy = model.set.misse[[model_index]]$phy, f = samp_frac, hidden.states = nturnover, pars = model.set.misse[[model_index]]$solution, AIC = model.set.misse[[model_index]]$AIC, root.type = "herr_als", n.cores = 30)
 model.recons.misse[[model_index]] <- hisse_recon
 save(hisse_recon, file = paste0("margin_recons/recon", model_index, ".Rsave"))
}
save(model.recons.misse, file = "model_recons_misse.Rsave")

#Get model-averaged tip rates
tip.rates.misse <- GetModelAveRates(model.recons.misse, type = c("tips"))
save(tip.rates.misse, file = "tip_rates.Rsave")