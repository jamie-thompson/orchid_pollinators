# 5b - Half-violin plots - pollinator strategies

library(colorspace)
library(dplyr)
library(ggplot2)
library(gghalves)
library(ggnewscale)
library(tidyr)

setwd("")

tol_vibrant <- c("#EE6677", "#228833", "#4477AA", "#CCBB44", "#66CCEE")
names(tol_vibrant) <- c("1", "2", "3", "6", "7")
state_labels <- c("1" = "Autonomous", "2" = "Reward: nectar", "3" = "Reward: lipids", "6" = "Deceit: food", "7" = "Deceit: sex")
color_mapping <- tol_vibrant
names(color_mapping) <- state_labels
color_mapping_misse <- darken(color_mapping, amount = 0.3)
names(color_mapping_misse) <- state_labels
tr_poll_att_5 <- read.csv("Orchids_poll_strat_5_states_BT_sample.csv")
tr_poll_att_5 <- tr_poll_att_5 %>%
  separate_rows(corhmm_state, sep = "&") %>%
  mutate(descriptive_state = state_labels[corhmm_state])
tr_poll_att_summary <- tr_poll_att_5 %>%
  group_by(descriptive_state) %>%
  summarise(count = n(), max_spec = max(spec, na.rm = TRUE), .groups = 'drop')
spec_strat_plot <- ggplot(tr_poll_att_5, aes(x = descriptive_state, y = log(spec), fill = descriptive_state)) +
  geom_violin(scale = "width", trim = TRUE, alpha = 0.5) +
  geom_boxplot(width = 0.2, outlier.shape = NA, alpha = 0.7) +
  geom_text(data = tr_poll_att_summary, aes(label = count), y = -2.3, vjust = 0, size = 5) +
  ylim(-2.85, 1.8) +
  labs(x = "Pollinator Strategy", y = "Speciation Rate (log)") +
  scale_fill_manual(values = color_mapping) +
  theme_classic(base_size = 14) +
  theme(legend.position = "none",
        axis.text.x = element_text(angle = 45, hjust = 1))
ggsave("Speciation_strategy_violin_BAMM.png", spec_strat_plot, width = 10, height = 6, dpi = 300)
load("tip_rates_misse.Rsave")
misse_tr <- tibble(taxon = tip.rates.misse$taxon, speciation = tip.rates.misse$speciation)
bamm_df <- tr_poll_att_5 %>%
  transmute(final_wcvp_name, descriptive_state, method = "BAMM", rate = spec)
misse_df <- tr_poll_att_5 %>%
  select(final_wcvp_name, descriptive_state) %>%
  left_join(misse_tr, by = c("final_wcvp_name" = "taxon")) %>%
  rename(rate = speciation) %>%
  mutate(method = "MiSSE") %>%
  select(final_wcvp_name, descriptive_state, method, rate)
rates_long <- bind_rows(bamm_df, misse_df) %>%
  mutate(log_rate = log(rate), method   = factor(method, levels = c("BAMM", "MiSSE")))
ymin <- -2.85; ymax <- 1.8
label_y <- ymin + 0.55
n_by_state_method <- rates_long %>%
  group_by(descriptive_state, method) %>%
  summarise(n = sum(!is.na(log_rate)), .groups = "drop")
spec_strat_halves <-
  ggplot(rates_long, aes(x = descriptive_state, y = log_rate)) +
    geom_half_violin(data = ~ dplyr::filter(.x, method == "BAMM"),
                   aes(fill = descriptive_state),
                   side = "l", trim = TRUE, alpha = .5, scale = "width", nudge = 0.025) +
  geom_half_boxplot(data = ~ dplyr::filter(.x, method == "BAMM"),
                    aes(fill = descriptive_state),
                    side = "l", width = .3, outlier.shape = NA, alpha = .8, nudge = 0.025) +
  scale_fill_manual(values = color_mapping, guide = "none") +
  ggnewscale::new_scale("fill") +
  geom_half_violin(data = ~ dplyr::filter(.x, method == "MiSSE"),
                   aes(fill = descriptive_state),
                   side = "r", trim = TRUE, alpha = .5, scale = "width", nudge = 0.025) +
  geom_half_boxplot(data = ~ dplyr::filter(.x, method == "MiSSE"),
                    aes(fill = descriptive_state),
                    side = "r", width = .3, outlier.shape = NA, alpha = .8, nudge = 0.025) +
  scale_fill_manual(values = color_mapping_misse, guide = "none") +
  geom_text(data = dplyr::filter(n_by_state_method, method == "BAMM"),
            aes(x = descriptive_state, y = label_y, label = n),
            inherit.aes = FALSE, vjust = 0, size = 4,
            position = position_nudge(x = -0.18)) +
  geom_text(data = dplyr::filter(n_by_state_method, method == "MiSSE"),
            aes(x = descriptive_state, y = label_y, label = n),
            inherit.aes = FALSE, vjust = 0, size = 4,
            position = position_nudge(x =  0.18)) +
  coord_cartesian(ylim = c(ymin, ymax)) +
  labs(x = "Pollinator Strategy", y = "Speciation Rate (log)") +
  theme_classic(base_size = 14) +
  theme(legend.position = "none",
        axis.text.x = element_text(angle = 45, hjust = 1))
ggsave("Speciation_strategy_half_violin_BAMM_vs_MiSSE.png",
       spec_strat_halves, width = 10, height = 6, dpi = 300)