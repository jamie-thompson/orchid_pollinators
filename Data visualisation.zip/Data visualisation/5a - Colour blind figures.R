# 5a - Colour blind figures

library(corHMM)
library(phytools)
library(ape)
library(circlize)
library(coda)
library(dplyr)
library(tidyr)
library(stringr)
library(scales)
library(ggplot2)

setwd("")

# Colour scheme, played around with this to find nice combinations that worked, this looked best
tol_vibrant <- c("#EE6677", "#228833", "#4477AA", "#CCBB44", "#66CCEE")
names(tol_vibrant) <- c("1", "2", "3", "6", "7")
state_labels <- c("1" = "Autonomous", "2" = "Reward: nectar",
                  "3" = "Reward: lipids", "6" = "Deceit: food",
                  "7" = "Deceit: sex")

# CorHMM ancestral states
best = readRDS("yang_5_state_Poll_Orch_2024_strategy_Upp_Bound_100_ARD_NoHidden_Model.RDS")
best_summary = readRDS("yang_5_state_Poll_Orch_2024_strategy_Upp_Bound_100_ARD_NoHidden_Model_300_SIMMAPs_summary.RDS")
pdf("SIMMAP_tree_tol_vibrant.pdf")
plot(best_summary, type = "fan", ftype = "off", colors = tol_vibrant)
dev.off()
pdf("SIMMAP_tree_tol_vibrant_tip_labels.pdf")
plot(best_summary, type = "fan", ftype = "i", fsize = 0.25, offset = 1.5, cex = 0.1, colors = tol_vibrant)
dev.off()
legend_labels <- c("Autonomous", "R: nectar", "R: lipids", "D: food", "D: sex")
legend_colors <- c("#EE6677", "#228833", "#4477AA", "#CCBB44", "#66CCEE")
legend_df <- data.frame( x = 1, y = seq_along(legend_labels), label = legend_labels, color = legend_colors)
legend_plot <- ggplot(legend_df, aes(x = 1, y = y)) +
  geom_point(aes(color = label), size = 10, shape = 16) +
  scale_color_manual(values = setNames(legend_colors, legend_labels)) +
  geom_text(aes(x = 1.2, label = label), size = 8, hjust = 0) +
  scale_y_reverse() +
  coord_cartesian(xlim = c(1, 3)) +
  theme_void() +
  theme(legend.position = "none")
ggsave("SIMMAP_legend_vibrant.png", legend_plot, width = 4, height = 3)


# Tip-coloured phylogenu
tip_states <- as.data.frame(best$data, stringsAsFactors = FALSE)
colnames(tip_states) <- c("tip.label", "state")
tip_states$state <- sapply(tip_states$state, function(x) strsplit(x, "&")[[1]][1])
tip_colors <- setNames(tol_vibrant[tip_states$state], tip_states$tip.label)
pdf("Tip_colored_tree_tol_vibrant.pdf")
plot(best$phy, type = "fan", show.tip.label = FALSE)
tiplabels(pch = 21, bg = tip_colors[best$phy$tip.label], cex = 1)
legend("bottomleft", legend = state_labels, fill = tol_vibrant, bty = "n")
dev.off()

# BayesTraits rj-MCMC chord diagrams
bt_op = read.csv("Orchid_strategy_rjMCMC_hp_exp_0_100_longer_12345_ARD.csv")
exclude_cols = c("Iteration", "Tree.No", "X", "No.Off.Parmeters", "No.Off.Zero", "Model.string")
cols_to_process = setdiff(colnames(bt_op), exclude_cols)
effective_sizes = list()
for (col_name in cols_to_process) {
  mcmc_obj = mcmc(bt_op[[col_name]])
  effective_sizes[[col_name]] = effectiveSize(mcmc_obj)
}
min(unlist(effective_sizes))
hist(unlist(effective_sizes))
hist(unlist(effective_sizes))

# Calculate HPDs
hpd_df = data.frame(Parameter = character(), lower_HPD = numeric(), upper_HPD = numeric(), median = numeric())

for (col_name in cols_to_process) {
  mcmc_obj <- mcmc(bt_op[[col_name]])
  hpd <- HPDinterval(mcmc_obj)
  med <- median(mcmc_obj)
  hpd_df <- rbind(hpd_df, data.frame(parameter = col_name, lower_HPD = hpd[1, "lower"], upper_HPD = hpd[1, "upper"], median = med))
}

# Chord diagrams
hpd_median = hpd_df[c("parameter", "median")]
colnames(hpd_median) = c("transition", "rate")
hpd_median <- hpd_median %>% filter(grepl("^q", transition))

# Make it into a matrix for circlize
hpd_median$from <- substr(hpd_median$transition, 2, 2)
hpd_median$to <- substr(hpd_median$transition, 3, 3)
hpd_median$transition = NULL
letter_replacements <- c("auto." = "A", "R: nectar" = "B", 
                         "R: lipids" = "C", "D: food" = "F", "D: sex" = "G")
hpd_median$from <- sapply(hpd_median$from, function(x) names(letter_replacements[letter_replacements == x]))
hpd_median$to <- sapply(hpd_median$to, function(x) names(letter_replacements[letter_replacements == x]))
hpd_median = hpd_median[c("from", "to", "rate")]
cols = setNames(c("#EE6677", "#228833", "#4477AA", "#CCBB44", "#66CCEE"),
                c("auto.", "R: nectar", "R: lipids", "D: food", "D: sex"))

plot_chord_diagram <- function(from_category) {
  link_colors <- sapply(1:nrow(hpd_median), function(i) {
    if (hpd_median$from[i] == from_category) {
      return(cols[hpd_median$to[i]])
    } else {
      return(alpha(cols[hpd_median$to[i]], 0.1))
    }
  })
  chordDiagram(hpd_median[, c("from", "to", "rate")], grid.col = cols, col = link_colors, annotationTrack = c("grid", "axis"), scale = FALSE, directional = 1, direction.type = "arrows", link.arr.length = 0.1, link.arr.type = "big.arrow")
  circos.clear()
}
par(mfrow = c(1,1))
pdf("Circos plots 5-state non-covarion model.pdf")
plot_chord_diagram("auto.")
plot_chord_diagram("R: nectar")
plot_chord_diagram("R: lipids")
plot_chord_diagram("D: food")
plot_chord_diagram("D: sex")
dev.off()
link_colors <- sapply(1:nrow(hpd_median), function(i) {
  return(cols[hpd_median$to[i]])
})
par(mfrow = c(1, 1))
pdf("Full circos 5-state plot non-covarion.pdf")
chordDiagram(hpd_median[, c("from", "to", "rate")], grid.col = cols, col = link_colors, annotationTrack = c("grid", "axis"), scale = FALSE, directional = 1, direction.type = "arrows", link.arr.length = 0.1, link.arr.type = "big.arrow")
dev.off()

# Speciation rate - pollinator strategy
tr_poll_att_5 <- read.csv("Orchids_poll_strat_5_states_BT_sample.csv")
tr_poll_att_5 <- tr_poll_att_5 %>%
  separate_rows(corhmm_state, sep = "&") %>%
  mutate(descriptive_state = state_labels[corhmm_state])
tr_poll_att_summary <- tr_poll_att_5 %>%
  group_by(descriptive_state) %>%
  summarise(count = n(), max_spec = max(spec, na.rm = TRUE), .groups = 'drop')
color_mapping <- setNames(tol_vibrant, names(state_labels))
names(color_mapping) <- state_labels
spec_strat_plot <- ggplot(tr_poll_att_5, aes(x = descriptive_state, y = log(spec), fill = descriptive_state)) +
  geom_violin(scale = "width", trim = TRUE, alpha = 0.5) +
  geom_boxplot(width = 0.2, outlier.shape = NA, alpha = 0.7) +
  geom_text(data = tr_poll_att_summary, aes(label = count), y = -2.3, vjust = 0, size = 5) +
  ylim(-2.85, 1.8) +
  labs(x = "Pollinator Strategy", y = "Speciation Rate (log)") +
  scale_fill_manual(values = color_mapping) +
  theme_classic(base_size = 14) +
  theme(legend.position = "none", axis.text.x = element_text(angle = 45, hjust = 1))
ggsave("Speciation_strategy_violin_plot.png", spec_strat_plot, width = 10, height = 6, dpi = 300)

# Speciation rate - pollination number and FPS
tr_poll_num <- read.csv("Orchid_tip_rates_poll_number.csv")
tr_poll_long <- tr_poll_num %>%
  pivot_longer(cols = c(number, fps), names_to = "Variable", values_to = "Value")
tr_poll_long$Variable <- recode(tr_poll_long$Variable,
                                "number" = "Number", "fps" = "FPS")
p1 <- ggplot(tr_poll_long, aes(x = Value, y = log(spec), color = Variable)) +
  geom_point(alpha = 0.6, size = 2.5) +
  scale_color_manual(values = c("Number" = "#4477AA", "FPS" = "#EE6677")) +
  labs(x = "Pollinator Number / Functional Pollination Specificity", 
       y = "Speciation Rate (log)", color = "Variable") +
  theme_minimal(base_size = 14) +
  theme(legend.position = c(0.8, 0.85), legend.title = element_text(size = 12), legend.text = element_text(size = 11), panel.grid = element_blank(), axis.line = element_line(color = "black"))
panel_colors <- c("Number" = "#4477AA", "FPS" = "#EE6677", 
                  "Generalist" = "#4477AA", "Specialist" = "#EE6677",
                  "Hymenoptera" = "#CCBB44", "Lepidoptera" = "#AA3377",
                  "Other" = "gray70")
p1 <- ggplot(tr_poll_long, aes(x = Value, y = log(spec), color = Variable)) +
  geom_point(alpha = 0.6, size = 3.5) +
  scale_color_manual(values = panel_colors) +
  labs(x = "Pollinator Number / Functional Pollination Specificity", 
       y = "Speciation Rate (log)", color = "Variable") +
  theme_minimal(base_size = 14) +
  ylim(-2.1, 1.8) +
  theme(legend.position = c(0.8, 0.85), panel.grid = element_blank(), axis.line = element_line(color = "black"))
tr_poll_num$poll_bin <- ifelse(tr_poll_num$number < 2, "Specialist", "Generalist")
summary_b <- tr_poll_num %>%
  group_by(poll_bin) %>%
  summarise(count = n())
n_groups <- length(unique(plot_df$group))
panel_colors <- scales::hue_pal()(n_groups)
names(panel_colors) <- unique(plot_df$group)
p_clades <- ggplot(plot_df, aes(x = group, y = log_rt_dist, fill = group)) +
  geom_violin(alpha = 0.5, scale = "width", trim = TRUE) +
  geom_boxplot(width = 0.2, outlier.shape = NA, alpha = 0.7) +
  scale_fill_manual(values = panel_colors) +
  labs(x = "Clade", y = "Pathwise distance (log)") +
  theme_minimal(base_size = 14) +
  theme(legend.position = "none", panel.grid = element_blank(), axis.line = element_line(color = "black"), axis.text.x = element_text(angle = 45, hjust = 1))
hymen <- read.csv("Pollinator attraction strategies 2024 WCVP cleaned final.csv")[c("final_wcvp_name", "HYMEN")]
colnames(hymen) <- c("species", "hymen")
hymen$species <- gsub(" ", "_", hymen$species)
hymen <- hymen %>%
  mutate(hymen = ifelse(hymen == 1, "Hymenoptera", "Other")) %>%
  replace_na(list(hymen = "Other"))
hymen_tr <- left_join(hymen, tr_poll_num, by = "species")
summary_c <- hymen_tr %>%
  group_by(hymen) %>%
  summarise(count = n())
p3 <- ggplot(hymen_tr, aes(x = hymen, y = log(spec), fill = hymen)) +
  geom_violin(alpha = 0.5, scale = "width", trim = TRUE) +
  geom_boxplot(width = 0.2, outlier.shape = NA, alpha = 0.7) +
  geom_text(data = summary_c, aes(x = hymen, y = -2.3, label = count), size = 5) +
  scale_fill_manual(values = panel_colors) +
  ylim(-2.35, 1.8) +
  labs(x = "Pollinator", y = "Speciation Rate (log)") +
  theme_minimal(base_size = 14) +
  theme(legend.position = "none", panel.grid = element_blank(), axis.line = element_line(color = "black"))
lepid <- read.csv("Pollinator attraction strategies 2024 WCVP cleaned final.csv")[c("final_wcvp_name", "LEPID")]
colnames(lepid) <- c("species", "lepid")
lepid$species <- gsub(" ", "_", lepid$species)
lepid <- lepid %>%
  mutate(lepid = ifelse(lepid == 1, "Lepidoptera", "Other")) %>%
  replace_na(list(lepid = "Other"))
lepid_tr <- left_join(lepid, tr_poll_num, by = "species")
summary_d <- lepid_tr %>%
  group_by(lepid) %>%
  summarise(count = n())
p4 <- ggplot(lepid_tr, aes(x = lepid, y = log(spec), fill = lepid)) +
  geom_violin(alpha = 0.5, scale = "width", trim = TRUE) +
  geom_boxplot(width = 0.2, outlier.shape = NA, alpha = 0.7) +
  geom_text(data = summary_d, aes(x = lepid, y = -2.3, label = count), size = 5) +
  scale_fill_manual(values = panel_colors) +
  ylim(-2.35, 1.8) +
  labs(x = "Pollinator", y = "Speciation Rate (log)") +
  theme_minimal(base_size = 14) +
  theme(legend.position = "none", panel.grid = element_blank(), axis.line = element_line(color = "black"))
combined_plot <- ggarrange(p1, p2, p3, p4, ncol = 2, nrow = 2, labels = c("a", "b", "c", "d"), font.label = list(size = 16))
ggsave("Speciation_pollination_all_panels_final.png", combined_plot, width = 10, height = 8, dpi = 300)