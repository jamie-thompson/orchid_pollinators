# 5c - Half-violin plot - pollinator number and FPS and identity

library(dplyr)
library(tidyr)
library(gghalves)
library(ggplot2)
library(ggpubr)
library(readr)
library(colorspace)
library(ggnewscale)

setwd("")

# Figure 41
blue <- "#4477AA" # number
red  <- "#EE6677" # FPS
blue_d <- darken(blue, 0.30)
red_d  <- darken(red,  0.30)
cat_cols_bamm  <- c("Number" = blue,  "FPS" = red)
cat_cols_misse <- c("Number" = blue_d, "FPS" = red_d)
tr_poll_num <- read_csv("Orchid_tip_rates_poll_number.csv", show_col_types = FALSE)
bamm_long <- tr_poll_num %>%
      transmute(species, number, fps, method = "BAMM", rate = spec)
load("tip_rates_misse.Rsave")
misse_tr <- tibble(species = tip.rates.misse$taxon, misse_rate = tip.rates.misse$speciation)
misse_long <- tr_poll_num %>%
  select(species, number, fps) %>%
  left_join(misse_tr, by = "species") %>%
  transmute(species, number, fps, method = "MiSSE", rate = misse_rate)
both <- bind_rows(bamm_long, misse_long) %>%
  mutate(log_rate = log(rate))
long_a <- both %>%
  select(species, method, log_rate, number, fps) %>%
  pivot_longer(c(number, fps), names_to = "Variable", values_to = "Value") %>%
  mutate(Variable = recode(Variable, number = "Number", fps = "FPS")) %>%
  filter(!is.na(Value), !is.na(log_rate))
p1 <- ggplot() +
  geom_point(data = dplyr::filter(long_a, method == "BAMM"), aes(x = Value, y = log_rate, color = Variable, shape = method), size = 3, alpha = 0.7) +
  scale_color_manual(values = cat_cols_bamm, name = "Variable") +
  scale_shape_manual(values = c(BAMM = 16, MiSSE = 17), name = "Method") +
  ggnewscale::new_scale_color() +
  geom_point(data = dplyr::filter(long_a, method == "MiSSE"), aes(x = Value, y = log_rate, color = Variable, shape = method), size = 3, alpha = 0.7) +
  scale_color_manual(values = cat_cols_misse, guide = "none") +
  labs(x = "Pollinator Number / Functional Pollination Specificity", y = "Speciation Rate (log)") +
  scale_y_continuous(limits = c(-2.1, 2.0), breaks = seq(-2, 2, 1)) +
  theme_minimal(base_size = 14) +
  theme(panel.grid = element_blank(), axis.line = element_line(color = "black"), legend.position = c(0.9, 0.8), legend.background = element_blank(), legend.box.background = element_blank(), legend.key = element_blank(), legend.title = element_text(size = 9), legend.text = element_text(size = 8), legend.key.size = unit(0.4, "cm"), legend.spacing.y = unit(0.2, "cm"))

# Figure 4b
grey0 <- "gray70" # 0 pollinators
blue1 <- "#4477AA" # 1 pollinator
red2p <- "#EE6677" # >1 pollinators
fill_bamm3  <- c("0" = grey0, "1" = blue1, ">1" = red2p)
fill_misse3 <- darken(fill_bamm3, amount = 0.30)
nud <- 0.025
ymin <- -2.35
ymax <- 1.8
label_y <- -2.3
tr_poll_num <- read_csv("Orchid_tip_rates_poll_number.csv", show_col_types = FALSE)
load("tip_rates_misse.Rsave")
misse_tr <- tibble(species = tip.rates.misse$taxon, misse_rate = tip.rates.misse$speciation)
bamm_long <- tr_poll_num %>%
  transmute(species, number, method = "BAMM", rate = spec)
misse_long <- tr_poll_num %>%
  select(species, number) %>%
  left_join(misse_tr, by = "species") %>%
  transmute(species, number, method = "MiSSE", rate = misse_rate)
both <- bind_rows(bamm_long, misse_long) %>%
  mutate(log_rate = log(rate))
dat_b3 <- both %>%
  mutate(poll_cat = case_when(is.na(number) ~ NA_character_, number == 0 ~ "0", number == 1 ~ "1", number >  1 ~ ">1")) %>%
  filter(!is.na(poll_cat), !is.na(log_rate)) %>%
  mutate(poll_cat = factor(poll_cat, levels = c("0","1",">1")),method = factor(method, levels = c("BAMM","MiSSE")))
n_b3 <- dat_b3 %>%
  group_by(poll_cat, method) %>%
  summarise(n = n(), .groups = "drop")
p2 <- ggplot(dat_b3, aes(x = poll_cat, y = log_rate)) +
  geom_half_violin(data = ~ dplyr::filter(.x, method=="BAMM"),aes(fill = poll_cat),side = "l", trim = TRUE, alpha = 0.5, scale = "width", position = position_nudge(x = -nud)) +
  geom_half_boxplot(data = ~ dplyr::filter(.x, method=="BAMM"), aes(fill = poll_cat), side = "l", width = 0.2, outlier.shape = NA, alpha = 0.8, position = position_nudge(x = -nud)) +
  scale_fill_manual(values = fill_bamm3, guide = "none") +
  ggnewscale::new_scale("fill") +
  geom_half_violin(data = ~ dplyr::filter(.x, method=="MiSSE"), aes(fill = poll_cat), side = "r", trim = TRUE, alpha = 0.5, scale = "width", position = position_nudge(x = nud)) +
  geom_half_boxplot(data = ~ dplyr::filter(.x, method=="MiSSE"), aes(fill = poll_cat), side = "r", width = 0.2, outlier.shape = NA, alpha = 0.8, position = position_nudge(x = nud)) +
  scale_fill_manual(values = fill_misse3, guide = "none") +
  geom_text(data = dplyr::filter(n_b3, method=="BAMM"), aes(x = poll_cat, y = label_y, label = n), inherit.aes = FALSE, size = 5, position = position_nudge(x = -0.15)) +
  geom_text(data = dplyr::filter(n_b3, method=="MiSSE"), aes(x = poll_cat, y = label_y, label = n), inherit.aes = FALSE, size = 5, position = position_nudge(x = 0.15)) +
  coord_cartesian(ylim = c(ymin, ymax)) +
  labs(x = "Pollinator Number", y = "Speciation Rate (log)") +
  theme_minimal(base_size = 14) +
  theme(legend.position = "none", panel.grid = element_blank(), axis.line = element_line(color = "black"))

# Figure 4c
fill_bamm  <- c("Hymenoptera" = "#CCBB44", "Other" = "gray70")
fill_misse <- colorspace::darken(fill_bamm, amount = 0.30)
hymen <- read.csv("Pollinator attraction strategies 2024 WCVP cleaned final.csv")[c("final_wcvp_name", "HYMEN")]
colnames(hymen) <- c("species", "hymen")
hymen$species <- gsub(" ", "_", hymen$species)
hymen <- hymen %>%
  mutate(hymen = ifelse(hymen == 1, "Hymenoptera", "Other")) %>%
  tidyr::replace_na(list(hymen = "Other"))
dat_c <- hymen %>%
  left_join(both, by = "species") %>%
  filter(!is.na(hymen), !is.na(log_rate)) %>%
  mutate(hymen = factor(hymen, levels = c("Hymenoptera","Other")))
n_c <- dat_c %>%
  group_by(hymen, method) %>%
  summarise(n = n(), .groups = "drop")
ymin <- -2.35
ymax <- 2.0
label_y <- -2.3
nud <- 0.025
label_nud <- 0.125
p3 <- ggplot(dat_c, aes(x = hymen, y = log_rate)) +
  geom_half_violin(data = ~ dplyr::filter(.x, method=="BAMM"), aes(fill = hymen), side="l", trim=TRUE, alpha=.5, scale="width", position = position_nudge(x = -nud)) +
  geom_half_boxplot(data = ~ dplyr::filter(.x, method=="BAMM"), aes(fill = hymen), side="l", width=.2, outlier.shape=NA, alpha=.8, position = position_nudge(x = -nud)) +
  scale_fill_manual(values = fill_bamm, guide="none") +
  ggnewscale::new_scale("fill") +
  geom_half_violin(data = ~ dplyr::filter(.x, method=="MiSSE"), aes(fill = hymen), side="r", trim=TRUE, alpha=.5, scale="width", position = position_nudge(x = nud)) +
  geom_half_boxplot(data = ~ dplyr::filter(.x, method=="MiSSE"), aes(fill = hymen), side="r", width=.2, outlier.shape=NA, alpha=.8, position = position_nudge(x = nud)) +
  scale_fill_manual(values = fill_misse, guide="none") +
  geom_text(data = dplyr::filter(n_c, method=="BAMM"), aes(x = hymen, y = label_y, label = n), inherit.aes = FALSE, size = 5, position = position_nudge(x = -label_nud)) +
  geom_text(data = dplyr::filter(n_c, method=="MiSSE"), aes(x = hymen, y = label_y, label = n), inherit.aes = FALSE, size = 5, position = position_nudge(x =  label_nud)) +
  coord_cartesian(ylim = c(ymin, ymax)) +
  labs(x = "Pollinator", y = "Speciation Rate (log)") +
  theme_minimal(base_size = 14) +
  theme(legend.position = "none", panel.grid = element_blank(), axis.line = element_line(color = "black"))

# Figure 4d
fill_bamm_d  <- c("Lepidoptera" = "#AA3377", "Other" = "gray70")
fill_misse_d <- colorspace::darken(fill_bamm_d, amount = 0.30)
lepid <- read.csv("Pollinator attraction strategies 2024 WCVP cleaned final.csv")[c("final_wcvp_name", "LEPID")]
colnames(lepid) <- c("species", "lepid")
lepid$species <- gsub(" ", "_", lepid$species)
lepid <- lepid %>%
  dplyr::mutate(lepid = ifelse(lepid == 1, "Lepidoptera", "Other")) %>%
  tidyr::replace_na(list(lepid = "Other"))
dat_d <- lepid %>%
  dplyr::left_join(both, by = "species") %>%
  dplyr::filter(!is.na(lepid), !is.na(log_rate)) %>%
  dplyr::mutate(lepid = factor(lepid, levels = c("Lepidoptera","Other")), method = factor(method, levels = c("BAMM","MiSSE")))
n_d <- dat_d %>%
  dplyr::group_by(lepid, method) %>%
  dplyr::summarise(n = n(), .groups = "drop")
ymin <- -2.35; ymax <- 2.0
label_y <- -2.3
nud <- 0.025
label_nud <- 0.125
p4 <- ggplot(dat_d, aes(x = lepid, y = log_rate)) +
  gghalves::geom_half_violin(data = ~ dplyr::filter(.x, method == "BAMM"), aes(fill = lepid), side = "l", trim = TRUE, alpha = 0.5, scale = "width", position = position_nudge(x = -nud)) +
  gghalves::geom_half_boxplot(data = ~ dplyr::filter(.x, method == "BAMM"), aes(fill = lepid), side = "l", width = 0.2, outlier.shape = NA, alpha = 0.8, position = position_nudge(x = -nud)) +
  scale_fill_manual(values = fill_bamm_d, guide = "none") +
  ggnewscale::new_scale("fill") +
  gghalves::geom_half_violin(data = ~ dplyr::filter(.x, method == "MiSSE"), aes(fill = lepid), side = "r", trim = TRUE, alpha = 0.5, scale = "width", position = position_nudge(x = nud)) +
  gghalves::geom_half_boxplot(data = ~ dplyr::filter(.x, method == "MiSSE"), aes(fill = lepid), side = "r", width = 0.2, outlier.shape = NA, alpha = 0.8, position = position_nudge(x = nud)) +
  scale_fill_manual(values = fill_misse_d, guide = "none") +
  geom_text(data = dplyr::filter(n_d, method == "BAMM"), aes(x = lepid, y = label_y, label = n), inherit.aes = FALSE, size = 5, position = position_nudge(x = -label_nud)) +
  geom_text(data = dplyr::filter(n_d, method == "MiSSE"), aes(x = lepid, y = label_y, label = n), inherit.aes = FALSE, size = 5, position = position_nudge(x = label_nud)) +
  coord_cartesian(ylim = c(ymin, ymax)) +
  labs(x = "Pollinator", y = "Speciation Rate (log)") +
  theme_minimal(base_size = 14) +
  theme(legend.position = "none", panel.grid = element_blank(), axis.line = element_line(color = "black"))

# Combine these
combined_plot <- ggarrange(p1, p2, p3, p4, ncol = 2, nrow = 2, labels = c("a","b","c","d"), font.label = list(size = 16))
ggsave("Speciation_pollination_halfviolins_BAMM_vs_MiSSE.png", combined_plot, width = 10, height = 8, dpi = 300)