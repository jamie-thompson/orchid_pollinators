# 2 New - CorHMM just 5 states root.p = NULL

library(corHMM)
library(dplyr)
library(geiger)
library(phytools)
library(stringr)

setwd("")

tree = read.tree("orchidoideae_reltime.tre")
poll = read.csv("Pollinator attraction strategies 2024 WCVP cleaned final.csv")[c("final_wcvp_name", "autonomous.selfing.agagamospermy", "nectar",	"pollen",	"trichomes.pseudo.pollen",	"fragr",	"lipids",	"sleep.sites",	"polyphenols.resins",	"brood.site.dec",	"food.dec",	"sex.dec")]
poll <- poll %>%
  select(where(~ !all(is.na(.))))
poll$final_wcvp_name = gsub(" ", "_", poll$final_wcvp_name)

letter_replacements <- c("autonomous.selfing.agagamospermy" = "A", "nectar" = "B", "lipids" = "C", "sleep.sites" = "D", 
                         "brood.site.dec" = "E", "food.dec" = "F", "sex.dec" = "G")
numeric_replacements <- setNames(as.character(1:7), LETTERS[1:7])

poll <- poll %>%
  mutate(across(all_of(names(letter_replacements)), ~ ifelse(. == 1, letter_replacements[cur_column()], .))) %>%
  rowwise() %>%
  mutate(state = paste(na.omit(c_across(names(letter_replacements))[c_across(names(letter_replacements)) %in% LETTERS]), collapse = "&")) %>%
  ungroup() %>%
  filter(state != "") %>%
  mutate(corhmm_state = str_replace_all(state, numeric_replacements))
poll$corhmm_state = as.factor(poll$corhmm_state)

shared_species = intersect(tree$tip.label, poll$final_wcvp_name)
poll = poll[poll$final_wcvp_name %in% shared_species,]
poll = poll[!poll$final_wcvp_name ==  "Caladenia_parva",] # Misplaced in tree, remove
table(poll$corhmm_state)

# CorHMM data prep
tr_poll_att_5 = read.csv("Orchids_poll_strat_5_states_BT_sample.csv")
tree_5 = keep.tip(tree, tr_poll_att_5$final_wcvp_name)
write.tree(tree_5, "Poll_strat_tree_5_states.tre")
Standard_Strict_Dataset = tr_poll_att_5[c("final_wcvp_name", "corhmm_state")]
Standard_Strict_Dataset = as.matrix(Standard_Strict_Dataset)
StandardTree = tree_5
table(tr_poll_att_5$corhmm_state)

# ARD No Dual Transitions
Strict_ARD_NoDual <- getStateMat4Dat(Standard_Strict_Dataset, model="ARD",dual = FALSE)
Strict_ARD_NoDual_NoHidden_Model <- corHMM(StandardTree,Standard_Strict_Dataset,rate.mat = Strict_ARD_NoDual$rate.mat, rate.cat=1,root.p="yang", n.cores=8,nstarts=100,node.states="none",ip=1,upper.bound = 100,get.tip.states = TRUE)
saveRDS(Strict_ARD_NoDual_NoHidden_Model,"yang_5_state_Poll_Orch_2024_strategy_Upp_Bound_100_ARD_NoHidden_Model.RDS")
# ER No Dual Transitions
Strict_ER_NoDual <- getStateMat4Dat(Standard_Strict_Dataset, model="ER", dual = FALSE)
Strict_ER_NoDual_NoHidden_Model <- corHMM(StandardTree,Standard_Strict_Dataset,rate.mat = Strict_ER_NoDual$rate.mat, rate.cat=1,root.p="yang", n.cores=8,nstarts=100,node.states="none",ip=1,upper.bound = 100,get.tip.states = TRUE)
saveRDS(Strict_ER_NoDual_NoHidden_Model,"yang_5_state_Poll_Orch_2024_strategy_Upp_Bound_100_ER_NoHidden_Model.RDS")

# STRICT with rate.cat = 2 ###

# ARD No Dual Transitions
ARD_strict_NoDual_Hidden2_R1 <- getStateMat4Dat(Standard_Strict_Dataset, model="ARD",dual = FALSE)$rate.mat
ARD_strict_NoDual_Hidden2_R2 <- getStateMat4Dat(Standard_Strict_Dataset, model="ARD",dual = FALSE)$rate.mat
Pp2 <- getRateCatMat(2)
Strict_ARD_NoDual_HiddenRatCat2 <- getFullMat(list(ARD_strict_NoDual_Hidden2_R1, ARD_strict_NoDual_Hidden2_R2), Pp2)
Strict_ARD_NoDual_HiddenRatCat2_Model <- corHMM(StandardTree,Standard_Strict_Dataset,rate.mat = Strict_ARD_NoDual_HiddenRatCat2, rate.cat=2,root.p="yang", n.cores=8,nstarts=100,node.states="none",ip=1,upper.bound = 100,get.tip.states = TRUE)
saveRDS(Strict_ARD_NoDual_HiddenRatCat2_Model,"yang_5_state_Poll_Orch_2024_strategy_Upp_Bound_100_ARD_HiddenRatCat2_Model.RDS")

# ER No Dual Transitions
ER_strict_NoDual_Hidden2_R1 <- getStateMat4Dat(Standard_Strict_Dataset, model="ER",dual = FALSE)$rate.mat
ER_strict_NoDual_Hidden2_R2 <- getStateMat4Dat(Standard_Strict_Dataset, model="ER",dual = FALSE)$rate.mat
Pp2 <- getRateCatMat(2)
Strict_ER_NoDual_HiddenRatCat2 <- getFullMat(list(ER_strict_NoDual_Hidden2_R1, ER_strict_NoDual_Hidden2_R2), Pp2)
Strict_ER_NoDual_HiddenRatCat2_Model <- corHMM(StandardTree,Standard_Strict_Dataset,rate.mat = Strict_ER_NoDual_HiddenRatCat2, rate.cat=2,root.p="yang", n.cores=8,nstarts=100,node.states="none",ip=1,upper.bound = 100,get.tip.states = TRUE)
saveRDS(Strict_ER_NoDual_HiddenRatCat2_Model,"yang_5_state_Poll_Orch_2024_strategy_Upp_Bound_100_ER_HiddenRatCat2_Model.RDS")

#SYMMETRIC RATES MODELS

# SYM No Dual Transitions
Strict_SYM_NoDual <- getStateMat4Dat(Standard_Strict_Dataset, model="SYM",dual = FALSE)
Strict_SYM_NoDual_NoHidden_Model <- corHMM(StandardTree,Standard_Strict_Dataset,rate.mat = Strict_SYM_NoDual$rate.mat, rate.cat=1,root.p="yang", n.cores=8,nstarts=100,node.states="none",ip=1,upper.bound = 100,get.tip.states = TRUE)
saveRDS(Strict_SYM_NoDual_NoHidden_Model,"yang_5_state_Poll_Orch_2024_strategy_Upp_Bound_100_SYM_NoHidden_Model.RDS")

# SYM No Dual Transitions
SYM_strict_NoDual_Hidden2_R1 <- getStateMat4Dat(Standard_Strict_Dataset, model="SYM",dual = FALSE)$rate.mat
SYM_strict_NoDual_Hidden2_R2 <- getStateMat4Dat(Standard_Strict_Dataset, model="SYM",dual = FALSE)$rate.mat
Pp2 <- getRateCatMat(2)
Strict_SYM_NoDual_HiddenRatCat2 <- getFullMat(list(SYM_strict_NoDual_Hidden2_R1, SYM_strict_NoDual_Hidden2_R2), Pp2)
Strict_SYM_NoDual_HiddenRatCat2_Model <- corHMM(StandardTree,Standard_Strict_Dataset,rate.mat = Strict_SYM_NoDual_HiddenRatCat2, rate.cat=2,root.p="yang",nstarts=100,node.states="none",ip=1,upper.bound = 100,get.tip.states = TRUE)
saveRDS(Strict_SYM_NoDual_HiddenRatCat2_Model,"yang_5_state_Poll_Orch_2024_strategy_Upp_Bound_100_SYM_HiddenRatCat2_Model.RDS")

AICc_Strict_Standard <- c(Strict_ER_NoDual_NoHidden_Model$AICc,
                          Strict_ER_NoDual_HiddenRatCat2_Model$AICc, 
                          Strict_ARD_NoDual_HiddenRatCat2_Model$AICc, 
                          Strict_ARD_NoDual_NoHidden_Model$AICc,
                          Strict_SYM_NoDual_HiddenRatCat2_Model$AICc,
                          Strict_SYM_NoDual_NoHidden_Model$AICc)

LogL_Strict_Standard <- c(Strict_ER_NoDual_NoHidden_Model$loglik,
                          Strict_ER_NoDual_HiddenRatCat2_Model$loglik, 
                          Strict_ARD_NoDual_HiddenRatCat2_Model$loglik, 
                          Strict_ARD_NoDual_NoHidden_Model$loglik,
                          Strict_SYM_NoDual_HiddenRatCat2_Model$loglik,
                          Strict_SYM_NoDual_NoHidden_Model$loglik)

All_Strict_AICc_Standard <-as.data.frame(AICc_Strict_Standard, row.names = c("Strict_ER_NoDual_NoHidden_Model",
                                                                             "Strict_ER_NoDual_HiddenRatCat2_Model", 
                                                                             "Strict_ARD_NoDual_HiddenRatCat2_Model", 
                                                                             "Strict_ARD_NoDual_NoHidden_Model",
                                                                             "Strict_SYM_NoDual_HiddenRatCat2_Model",
                                                                             "Strict_SYM_NoDual_NoHidden_Model"))

All_Strict_Standard <-as.data.frame(LogL_Strict_Standard, row.names = c("Strict_ER_NoDual_NoHidden_Model",
                                                                        "Strict_ER_NoDual_HiddenRatCat2_Model", 
                                                                        "Strict_ARD_NoDual_HiddenRatCat2_Model", 
                                                                        "Strict_ARD_NoDual_NoHidden_Model",
                                                                        "Strict_SYM_NoDual_HiddenRatCat2_Model",
                                                                        "Strict_SYM_NoDual_NoHidden_Model"))

All_Strict_Standard$AICc<-All_Strict_AICc_Standard
aicw_strict_Standard <- aicw(AICc_Strict_Standard)
All_Strict_Standard$AICw<-aicw_strict_Standard$w

Models_StandardStrict <- c(list(Strict_ARD_NoDual_HiddenRatCat2_Model,
                                Strict_ARD_NoDual_NoHidden_Model,
                                Strict_ER_NoDual_HiddenRatCat2_Model,
                                Strict_ER_NoDual_NoHidden_Model,
                                Strict_SYM_NoDual_HiddenRatCat2_Model,
                                Strict_SYM_NoDual_NoHidden_Model))

AllTable_StandardStrict <- matrix(0, length(Models_StandardStrict), 4)
rownames(AllTable_StandardStrict) <- rep(c("Standard_Strict_ARD_NoDual_HiddenRatCat2_Model",
                                           "Standard_Strict_ARD_NoDual_NoHidden_Model",
                                           "Standard_Strict_ER_NoDual_HiddenRatCat2_Model",
                                           "Standard_Strict_ER_NoDual_NoHidden_Model",
                                           "Standard_Strict_SYM_NoDual_HiddenRatCat2_Model",
                                           "Standard_Strict_SYM_NoDual_NoHidden_Model"))

colnames(AllTable_StandardStrict) <- c("k.rate", "AICc", "MeanRate", "LogL")

AllTable_StandardStrict <- as.data.frame(AllTable_StandardStrict)

#For loop to put everything into a nice table
for(i in 1:length(Models_StandardStrict)){
  k.rate <- max(Models_StandardStrict[[i]]$index.mat, na.rm = TRUE)
  AICc <- round(Models_StandardStrict[[i]]$AICc, 2)
  MeanRate <- round(mean(Models_StandardStrict[[i]]$solution, na.rm = TRUE),2)
  AllTable_StandardStrict$k.rate[i] <- print(k.rate)
  AllTable_StandardStrict$AICc[i] <- print(AICc)
  AllTable_StandardStrict_AICw <- aicw(AllTable_StandardStrict$AICc)
  AllTable_StandardStrict$AICw <- round(AllTable_StandardStrict_AICw$w,2)
  AllTable_StandardStrict$LogL <- All_Strict_Standard$LogL_Strict_Standard
  AllTable_StandardStrict$MeanRate[i] <- print(MeanRate)
  View(AllTable_StandardStrict)
}

write.csv(AllTable_StandardStrict,"yang_5_state_Poll_Orch_2024_strategy_Upp_Bound_100_CorHMM_AllTable_StandardStrict.csv")

# SIMMAPs
# Re-read best model back in if necessary
best = readRDS("yang_5_state_Poll_Orch_2024_strategy_Upp_Bound_100_ARD_NoHidden_Model.RDS")
best_marginal <- corHMM(StandardTree,Standard_Strict_Dataset,rate.mat = Strict_ARD_NoDual$rate.mat, rate.cat=1,root.p="yang", n.cores=8,nstarts=100,node.states="marginal",ip=1,upper.bound = 100,get.tip.states = TRUE)
saveRDS(best_marginal, "yang_5_state_Poll_Orch_2024_strategy_Upp_Bound_100_ARD_NoHidden_Model_marginal.RDS")

best_simmap = corHMM::makeSimmap(best$phy, best$data, best$solution, rate.cat = 1, nSim = 300)
saveRDS(best_simmap, "yang_5_state_Poll_Orch_2024_strategy_Upp_Bound_100_ARD_NoHidden_Model_300_SIMMAPs.RDS")
best_summary = summary(best_simmap)
saveRDS(best_summary, "yang_5_state_Poll_Orch_2024_strategy_Upp_Bound_100_ARD_NoHidden_Model_300_SIMMAPs_summary.RDS")
count_sim = countSimmap(best_simmap,colnames(best_simmap[[1]]$Q))
write.csv(count_sim, "count_summary_yang_5_state_Poll_Orch_2024_strategy_Upp_Bound_100_ARD_NoHidden_Model_300_SIMMAPs.csv")