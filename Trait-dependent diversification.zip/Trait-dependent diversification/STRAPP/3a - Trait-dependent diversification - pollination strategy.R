# 3a - Trait-dependent diversification - pollination strategy

library(BAMMtools)
library(dplyr)
library(ggplot2)
library(ggpubr)
library(stringr)

setwd("")

# Read data
strategy = read.csv("Poll_Orch_2024_strategy_bt_sample.csv")[c("final_wcvp_name", "corhmm_state")]
tree = read.tree("orchidoideae_reltime.tre")
ed = getEventData(tree, "reltime_event_data.txt", 0.1)
# num_shifts <- sapply(ed$eventData, function(x) length(x$node) - 1)
# mean(num_shifts)
# median(num_shifts)

# A reminder
# letter_replacements <- c("autonomous.selfing.agagamospermy" = "A", "nectar" = "B", "lipids" = "C", "sleep.sites" = "D", 
#                          "brood.site.dec" = "E", "food.dec" = "F", "sex.dec" = "G")
# numeric_replacements <- setNames(as.character(1:7), LETTERS[1:7])

# Get tip rates for visualisation later on
tr = getTipRates(ed)
tr = data.frame(final_wcvp_name = names(tr$lambda.avg), spec = tr$lambda.avg, ext = tr$mu.avg)
tr$net_div = tr$spec-tr$ext
write.csv(tr, "Orchids_reltime_tip_rates_avg.csv")
poll_att_ed = subtreeBAMM(ed, strategy$final_wcvp_name)
tr_poll_att = inner_join(tr, strategy)
tr_poll_att$corhmm_state = as.factor(tr_poll_att$corhmm_state)
write.csv(tr_poll_att, "Orchid_tip_rates_poll_strat.csv")

# Test all states
sink("Orchid pollinator strategy all states selfing STRAPP.txt")
"Spec"
traitDependentBAMM(poll_att_ed, setNames(tr_poll_att$corhmm_state, tr_poll_att$final_wcvp_name), rate = "speciation", method = "k")
sink()

# Test all individually
sink("STRAPP_results_states_1_to_7.txt")

# Loop over states 1 to 7
for (state in 1:7) {
  tr_poll_att <- tr_poll_att %>%
    mutate(temp_bin = if_else(str_detect(corhmm_state, paste0("\\b", state, "\\b")), 1, 0))
  result <- traitDependentBAMM(poll_att_ed, setNames(tr_poll_att$temp_bin, tr_poll_att$final_wcvp_name), rate = "speciation", method = "m")
  print(result)
}
sink()

# Test reward vs deception vs selfing - be strict, if grouped and 2&3 then remove, if 2&2 then score as 2
tr_poll_att_3_state_strict <- tr_poll_att %>%
  rowwise() %>%
  mutate(three_comp = if_else(
    str_detect(corhmm_state, "&"),
    {
      split_states <- unlist(str_split(corhmm_state, "&"))
      converted_states <- case_when(split_states == "1" ~ "1",
                                    split_states %in% c("2", "3", "4") ~ "2",
                                    split_states %in% c("5", "6", "7") ~ "3",
                                    TRUE ~ NA_character_)
      if_else(all(converted_states == converted_states[1]), converted_states[1], NA_character_)
    },
    case_when(corhmm_state == "1" ~ "1",
      corhmm_state %in% c("2", "3", "4") ~ "2",
      corhmm_state %in% c("5", "6", "7") ~ "3",
      TRUE ~ NA_character_)
  )) %>%
  ungroup() %>%
  filter(!is.na(three_comp))

tr_poll_att_3_state_strict$three_comp = as.factor(tr_poll_att_3_state_strict$three_comp)
tr_poll_att_3_state_strict_ed = subtreeBAMM(ed, tr_poll_att_3_state_strict$final_wcvp_name)

sink("Orchid pollinator strategy self vs reward vs deceit STRAPP all 7 states.txt")
"Spec"
traitDependentBAMM(tr_poll_att_3_state_strict_ed, setNames(tr_poll_att_3_state_strict$three_comp, tr_poll_att_3_state_strict$final_wcvp_name), rate = "speciation", method = "k")
sink()

# Plot this
tr_poll_att_3_state_strict = tr_poll_att_3_state_strict %>% mutate(three_comp_verbose = case_when(
  three_comp == "1" ~ "autonomous",
  three_comp == "2" ~ "reward",
  three_comp == "3" ~ "deceit"))

# Test all states without the polymorphic ones
tr_poll_att_singles = tr_poll_att %>%
  filter(!str_detect(corhmm_state, "&"))
poll_att_ed_single = subtreeBAMM(tr_poll_att_3_state_strict_ed, tr_poll_att_singles$final_wcvp_name)
sink("Orchid pollinator strategy all states just single states STRAPP.txt")
"Spec"
traitDependentBAMM(poll_att_ed_single, setNames(tr_poll_att_singles$corhmm_state, tr_poll_att_singles$final_wcvp_name), rate = "speciation", method = "k")
sink()

# Test the three comparison without multistate species
tr_poll_att_3_comp_no_poly = tr_poll_att %>%
  filter(!str_detect(three_comp, "&"))
tr_poll_att_3_comp_no_poly_ed = subtreeBAMM(ed, tr_poll_att_3_comp_no_poly$final_wcvp_name)
sink("Orchid pollinator strategy 3 comparison no ampersands just single states STRAPP.txt")
"Spec"
traitDependentBAMM(tr_poll_att_3_comp_no_poly_ed, setNames(tr_poll_att_3_comp_no_poly$three_comp, tr_poll_att_3_comp_no_poly$final_wcvp_name), rate = "speciation", method = "k")
sink()

### Now test without the low-sampled states
tr_poll_att_5_states = tr_poll_att[!tr_poll_att$corhmm_state %in% c(4,5),]
tr_poll_att_5_states_ed = subtreeBAMM(ed, tr_poll_att_5_states$final_wcvp_name)

# STRAPP all states
sink("Orchid pollinator strategy 5 states all combos selfing STRAPP.txt")
"Spec"
traitDependentBAMM(tr_poll_att_5_states_ed, setNames(tr_poll_att_5_states$corhmm_state, tr_poll_att_5_states$final_wcvp_name), rate = "speciation", method = "k")
sink()

# Try all 5 states without the polymorphic ones
tr_poll_att_5_states_singles = tr_poll_att_5_states %>%
  filter(!str_detect(corhmm_state, "&"))
poll_att_5_states_ed_single = subtreeBAMM(ed, tr_poll_att_5_states_singles$final_wcvp_name)
sink("Orchid pollinator strategy 5 states just single states STRAPP.txt")
"Spec"
traitDependentBAMM(poll_att_5_states_ed_single, setNames(tr_poll_att_5_states_singles$corhmm_state, tr_poll_att_5_states_singles$final_wcvp_name), rate = "speciation", method = "k")
sink()