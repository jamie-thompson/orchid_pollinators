# 3b - Trait-dependent diversification - pollinator number and FPS

library(BAMMtools)
library(dplyr)
library(ggplot2)
library(ggpubr)
library(MASS)
library(MCMCglmm)
library(scales)
library(tidyr)

setwd("")

# Read tree and BAMM event data
tree <- read.tree("orchidoideae_reltime.tre")
ed <- getEventData(tree, "reltime_event_data.txt", 0.1)

# Read tip rate data
tr <- read.csv("Orchids_reltime_tip_rates_avg.csv")[c("final_wcvp_name", "spec", "ext", "net_div")]
colnames(tr) <- c("species", "spec", "ext", "net_div")
tr$species <- gsub(" ", "_", tr$species)

# Read pollination data with selfing
poll_data <- read.csv("Pollinator attraction strategies 2024 WCVP cleaned final.csv")[
  c("final_wcvp_name", "species.num.pol..ePS.", "order.x.fam..fPS.", "autonomous.selfing.agagamospermy")
]
colnames(poll_data) <- c("species", "number", "fps", "selfing")
poll_data$species <- gsub(" ", "_", poll_data$species)

# Replace number with 0 if NA and selfing is 1
poll_data$number <- ifelse(is.na(poll_data$number) & poll_data$selfing == 1, 0, poll_data$number)

# Clean
poll_data <- poll_data[!poll_data$species == "Caladenia_parva", ]
poll_data <- poll_data[poll_data$species %in% tree$tip.label, ]
poll_data <- poll_data %>%
  filter(!is.na(number) & (!is.na(fps) | number == 0))
tr_poll_num <- inner_join(tr, poll_data)

# STRAPP pollinator number number
sink("Orchid pollinator number Spearman STRAPP.txt")
traitDependentBAMM(poll_num_ed, setNames(tr_poll_num$number, tr_poll_num$species), rate = "speciation", method = "s")
sink()

# Do the same without species with 0s
tr_poll_num_no_zero = tr_poll_num[tr_poll_num$number > 0,]
poll_num_ed_no_zero = subtreeBAMM(poll_num_ed, tr_poll_num_no_zero$species)

# Raw
sink("Orchid pollinator number no zero Spearman STRAPP.txt")
traitDependentBAMM(poll_num_ed_no_zero, setNames(tr_poll_num_no_zero$number, tr_poll_num_no_zero$species), rate = "speciation", method = "s")
sink()

# Raw
sink("Orchid pollinator FPS no zero Spearman STRAPP.txt")
traitDependentBAMM(poll_num_ed_no_zero, setNames(tr_poll_num_no_zero$fps, tr_poll_num_no_zero$species), rate = "speciation", method = "s")
sink()

# Categorical (0 = selfing, 1 = single, 2 = multiple)
tr_poll_num$poll_cat <- case_when(tr_poll_num$number == 0 ~ 0,
                                  tr_poll_num$number == 1 ~ 1,
                                  tr_poll_num$number > 1 ~ 2)

sink("Orchid pollinator number categorical Kruskal STRAPP.txt")
traitDependentBAMM(poll_num_ed, setNames(tr_poll_num$poll_cat, tr_poll_num$species), rate = "speciation", method = "k")
sink()

# Test Hymenoptera
hymen = read.csv("Pollinator attraction strategies 2024 WCVP cleaned final.csv")[c("final_wcvp_name", "HYMEN")]
colnames(hymen) = c("species", "hymen")
hymen$species = gsub(" ", "_", hymen$species)
shared_species = intersect(tree$tip.label, hymen$species)
hymen = hymen[hymen$species %in% shared_species,]
hymen = hymen[!hymen$species == "Caladenia_parva",]
hymen <- hymen %>%
  mutate(hymen = ifelse(hymen == 1, 1, 0)) %>%
  replace_na(list(hymen = 0))
hymen_ed = subtreeBAMM(ed, hymen$species)
sink("Orchid hymenoptera binary STRAPP.txt")
"Speciation"
traitDependentBAMM(hymen_ed, setNames(hymen$hymen, hymen$species), rate = "speciation", method = "m")
sink()

# Test Lepidoptera
lepid = read.csv("Pollinator attraction strategies 2024 WCVP cleaned final.csv")[c("final_wcvp_name", "LEPID")]
colnames(lepid) = c("final_wcvp_name", "lepid")
lepid$final_wcvp_name = gsub(" ", "_", lepid$final_wcvp_name)
shared_species = intersect(tree$tip.label, lepid$final_wcvp_name)
lepid = lepid[lepid$final_wcvp_name %in% shared_species,]
lepid = lepid[!lepid$final_wcvp_name == "Caladenia_parva",]
lepid <- lepid %>%
  mutate(lepid = ifelse(lepid == 1, 1, 0)) %>%
  replace_na(list(lepid = 0))
lepid_ed = subtreeBAMM(ed, lepid$species)
sink("Orchid lepidoptera binary STRAPP.txt")
"Speciation"
traitDependentBAMM(lepid_ed, setNames(lepid$lepid, lepid$species), rate = "speciation", method = "m")
sink()