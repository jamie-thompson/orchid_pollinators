# MiSSE trait-dependent diversification

library(ape)
library(phylolm)
library(dplyr)
library(tidyr)
library(readr)
library(stringr)

setwd("")

# Get tree and data
tree = read.tree("orchidoideae_reltime.tre")
load("tip_rates_misse.Rsave")
misse_tbl <- tibble(species = tip.rates.misse$taxon, misse = tip.rates.misse$speciation)
numfps <- read_csv("Orchid_tip_rates_poll_number.csv", show_col_types = FALSE)
strategy <- read_csv("Poll_Orch_2024_strategy_bt_sample.csv", show_col_types = FALSE) |> transmute(species = gsub(" ", "_", final_wcvp_name), corhmm_state = as.character(corhmm_state))
orders <- read_csv("Pollinator attraction strategies 2024 WCVP cleaned final.csv", show_col_types = FALSE) |> transmute(species = gsub(" ", "_", final_wcvp_name), HYMEN = as.integer(HYMEN == 1), LEPID = as.integer(LEPID == 1))
combined <- numfps |> rename(species = species) |> select(species, number, fps) |> left_join(strategy, by = "species") |> left_join(orders, by = "species") |> left_join(misse_tbl, by = "species") |> mutate(log_rate = log(misse))

# Describe data without polymorphics
state_labels <- c("1"="Autonomous","2"="Reward: nectar","3"="Reward: lipids",
 "6"="Deceit: food","7"="Deceit: sex")
stats_description <- combined |>
 filter(!is.na(misse), !is.na(corhmm_state), !str_detect(corhmm_state, "&")) |> mutate(state_lab = state_labels[corhmm_state]) |> filter(!is.na(state_lab)) |> group_by(state_lab) |> summarise(n = n(), mean_misse = mean(misse), sd_misse = sd(misse), .groups = "drop")
stats_description

## The following code works but is not pretty - I wrote it for one, then just copied and pasted for all tests

# All strategies with polymorphics
dat <- combined |> filter(!is.na(log_rate), !is.na(corhmm_state)) |> mutate(group = corhmm_state)
keep <- intersect(tree$tip.label, dat$species)
phy <- keep.tip(tree, keep)
dat <- dat |> filter(species %in% keep)
dat <- dat[match(phy$tip.label, dat$species), , drop = FALSE]
dat <- as.data.frame(dat); rownames(dat) <- dat$species
sink("MiSSE_all_strategies_poly.txt")
fit <- phylolm(log_rate ~ factor(group), data = dat, phy = phy, model = "lambda")
summary(fit)
sink()

# All strategies without polymorphics
dat <- combined |> filter(!is.na(log_rate), !is.na(corhmm_state), !str_detect(corhmm_state, "&")) |> mutate(group = corhmm_state)
keep <- intersect(tree$tip.label, dat$species)
phy <- keep.tip(tree, keep)
dat <- dat |> filter(species %in% keep)
dat <- dat[match(phy$tip.label, dat$species), , drop = FALSE]
dat <- as.data.frame(dat); rownames(dat) <- dat$species
sink("MiSSE_all_strategies_singles.txt")
fit <- phylolm(log_rate ~ factor(group), data = dat, phy = phy, model = "lambda")
summary(fit)
sink()

# Strategies binarised - lipids
dat <- combined |> mutate(bin = ifelse(!is.na(corhmm_state) & str_detect(paste0("&", corhmm_state, "&"), "&3&"), 1L, 0L)) |> filter(!is.na(log_rate), !is.na(bin))
keep <- intersect(tree$tip.label, dat$species)
phy <- keep.tip(tree, keep)
dat <- dat |> filter(species %in% keep)
dat <- dat[match(phy$tip.label, dat$species), , drop = FALSE]
dat <- as.data.frame(dat); rownames(dat) <- dat$species
sink("MiSSE_binary_lipid.txt")
fit <- phylolm(log_rate ~ as.factor(bin), data = dat, phy = phy, model = "lambda")
summary(fit)
sink()

# Sex deception
dat <- combined |> mutate(bin = ifelse(!is.na(corhmm_state) & str_detect(paste0("&", corhmm_state, "&"), "&7&"), 1L, 0L)) |> filter(!is.na(log_rate), !is.na(bin))
keep <- intersect(tree$tip.label, dat$species)
phy <- keep.tip(tree, keep)
dat <- dat |> filter(species %in% keep)
dat <- dat[match(phy$tip.label, dat$species), , drop = FALSE]
dat <- as.data.frame(dat); rownames(dat) <- dat$species
sink("MiSSE_binary_sexdeception.txt")
fit <- phylolm(log_rate ~ as.factor(bin), data = dat, phy = phy, model = "lambda")
summary(fit)
sink()

# Autonomous selfing
dat <- combined |> mutate(bin = ifelse(!is.na(corhmm_state) & str_detect(paste0("&", corhmm_state, "&"), "&1&"), 1L, 0L)) |> filter(!is.na(log_rate), !is.na(bin))
keep <- intersect(tree$tip.label, dat$species)
phy <- keep.tip(tree, keep)
dat <- dat |> filter(species %in% keep)
dat <- dat[match(phy$tip.label, dat$species), , drop = FALSE]
dat <- as.data.frame(dat); rownames(dat) <- dat$species
sink("MiSSE_binary_autonomous.txt")
fit <- phylolm(log_rate ~ as.factor(bin), data = dat, phy = phy, model = "lambda")
summary(fit)
sink()

# Nectar reward
dat <- combined |> mutate(bin = ifelse(!is.na(corhmm_state) & str_detect(paste0("&", corhmm_state, "&"), "&2&"), 1L, 0L)) |> filter(!is.na(log_rate), !is.na(bin))
keep <- intersect(tree$tip.label, dat$species)
phy <- keep.tip(tree, keep)
dat <- dat |> filter(species %in% keep)
dat <- dat[match(phy$tip.label, dat$species), , drop = FALSE]
dat <- as.data.frame(dat); rownames(dat) <- dat$species
sink("MiSSE_binary_nectar.txt")
fit <- phylolm(log_rate ~ as.factor(bin), data = dat, phy = phy, model = "lambda")
summary(fit)
sink()

# Food deception
dat <- combined |> mutate(bin = ifelse(!is.na(corhmm_state) & str_detect(paste0("&", corhmm_state, "&"), "&6&"), 1L, 0L)) |> filter(!is.na(log_rate), !is.na(bin))
keep <- intersect(tree$tip.label, dat$species)
phy <- keep.tip(tree, keep)
dat <- dat |> filter(species %in% keep)
dat <- dat[match(phy$tip.label, dat$species), , drop = FALSE]
dat <- as.data.frame(dat); rownames(dat) <- dat$species
sink("MiSSE_binary_fooddeception.txt")
fit <- phylolm(log_rate ~ as.factor(bin), data = dat, phy = phy, model = "lambda")
summary(fit)
sink()

# Broad 3-category
state_map <- tibble( state = as.character(1:7), group = c("autonomous", "reward", "reward", "reward", "deceit", "deceit", "deceit"))
dat <- combined |> mutate(.row = row_number()) |> separate_longer_delim(corhmm_state, delim = "&") |> rename(state = corhmm_state) |> left_join(state_map, by = "state") |> group_by(.row) |> summarise(across(everything(), ~ first(.x)), group = if (any(is.na(group)) || dplyr::n_distinct(group) != 1L) NA_character_ else first(group), .groups = "drop") |> filter(!is.na(group), !is.na(log_rate)) |> select(-.row)
keep <- intersect(tree$tip.label, dat$species)
phy <- keep.tip(tree, keep)
dat <- dat |> filter(species %in% keep)
dat <- dat[match(phy$tip.label, dat$species), , drop = FALSE]
dat <- as.data.frame(dat); rownames(dat) <- dat$species
sink("MiSSE_broad3_strict.txt")
fit <- phylolm(log_rate ~ factor(group), data = dat, phy = phy, model = "lambda")
summary(fit)
sink()

# Pollinator number - normal, do rank later just to sanity check
dat <- combined |> filter(!is.na(log_rate), !is.na(number))
keep <- intersect(tree$tip.label, dat$species)
phy <- keep.tip(tree, keep)
dat <- dat |> filter(species %in% keep)
dat <- dat[match(phy$tip.label, dat$species), , drop = FALSE]
dat <- as.data.frame(dat); rownames(dat) <- dat$species
sink("MiSSE_number_all_raw.txt")
fit <- phylolm(log_rate ~ number, data = dat, phy = phy, model = "lambda")
summary(fit)
sink()

# Pollinator number rank
dat <- combined |> filter(!is.na(log_rate), !is.na(number))
keep <- intersect(tree$tip.label, dat$species)
phy <- keep.tip(tree, keep)
dat <- dat |> filter(species %in% keep)
dat$rank_rate <- rank(dat$log_rate, ties.method = "average")
dat$rank_num <- rank(dat$number, ties.method = "average")
dat <- dat[match(phy$tip.label, dat$species), , drop = FALSE]
dat <- as.data.frame(dat); rownames(dat) <- dat$species
sink("MiSSE_number_all_rank.txt")
fit <- phylolm(rank_rate ~ rank_num, data = dat, phy = phy, model = "lambda")
summary(fit)
sink()

# FPS - normal again
dat <- combined |> filter(!is.na(log_rate), !is.na(fps))
keep <- intersect(tree$tip.label, dat$species)
phy <- keep.tip(tree, keep)
dat <- dat |> filter(species %in% keep)
dat <- dat[match(phy$tip.label, dat$species), , drop = FALSE]
dat <- as.data.frame(dat); rownames(dat) <- dat$species
sink("MiSSE_fps_all_raw.txt")
fit <- phylolm(log_rate ~ fps, data = dat, phy = phy, model = "lambda")
summary(fit)
sink()

# FPS rank-based
dat <- combined |> filter(!is.na(log_rate), !is.na(fps))
keep <- intersect(tree$tip.label, dat$species)
phy <- keep.tip(tree, keep)
dat <- dat |> filter(species %in% keep)
dat$rank_rate <- rank(dat$log_rate, ties.method = "average")
dat$rank_fps <- rank(dat$fps, ties.method = "average")
dat <- dat[match(phy$tip.label, dat$species), , drop = FALSE]
dat <- as.data.frame(dat); rownames(dat) <- dat$species
sink("MiSSE_fps_all_rank.txt")
fit <- phylolm(rank_rate ~ rank_fps, data = dat, phy = phy, model = "lambda")
summary(fit)
sink()

# Pollinator number without autonomous selfers
dat <- combined |> filter(!is.na(log_rate), !is.na(number), number > 0)
keep <- intersect(tree$tip.label, dat$species)
phy <- keep.tip(tree, keep)
dat <- dat |> filter(species %in% keep)
dat <- dat[match(phy$tip.label, dat$species), , drop = FALSE]
dat <- as.data.frame(dat); rownames(dat) <- dat$species
sink("MiSSE_number_no0_raw.txt")
fit <- phylolm(log_rate ~ number, data = dat, phy = phy, model = "lambda")
summary(fit)
sink()

# Pollinator number without selfers rank-based
dat <- combined |> filter(!is.na(log_rate), !is.na(number), number > 0)
keep <- intersect(tree$tip.label, dat$species)
phy <- keep.tip(tree, keep)
dat <- dat |> filter(species %in% keep)
dat$rank_rate <- rank(dat$log_rate, ties.method = "average")
dat$rank_num <- rank(dat$number, ties.method = "average")
dat <- dat[match(phy$tip.label, dat$species), , drop = FALSE]
dat <- as.data.frame(dat); rownames(dat) <- dat$species
sink("MiSSE_number_no0_rank.txt")
fit <- phylolm(rank_rate ~ rank_num, data = dat, phy = phy, model = "lambda")
summary(fit)
sink()

# FPS without selfers - normal
dat <- base |> filter(!is.na(log_rate), !is.na(number), number > 0, !is.na(fps))
keep <- intersect(tree$tip.label, dat$species)
phy <- keep.tip(tree, keep)
dat <- dat |> filter(species %in% keep)
dat <- dat[match(phy$tip.label, dat$species), , drop = FALSE]
dat <- as.data.frame(dat); rownames(dat) <- dat$species
sink("MiSSE_fps_no0_raw.txt")
fit <- phylolm(log_rate ~ fps, data = dat, phy = phy, model = "lambda")
summary(fit)
sink()

# FPS wthout selfers rank-based
dat <- combined |> filter(!is.na(log_rate), !is.na(number), number > 0, !is.na(fps))
keep <- intersect(tree$tip.label, dat$species)
phy <- keep.tip(tree, keep)
dat <- dat |> filter(species %in% keep)
dat$rank_rate <- rank(dat$log_rate, ties.method = "average")
dat$rank_fps <- rank(dat$fps, ties.method = "average")
dat <- dat[match(phy$tip.label, dat$species), , drop = FALSE]
dat <- as.data.frame(dat); rownames(dat) <- dat$species
sink("MiSSE_fps_no0_rank.txt")
fit <- phylolm(rank_rate ~ rank_fps, data = dat, phy = phy, model = "lambda")
summary(fit)
sink()

# Specialsiation - factor-based
dat <- combined |> mutate(spec_level = case_when(!is.na(number) & number == 0 ~ "0", !is.na(number) & number == 1 ~ "1", !is.na(number) & number > 1 ~ ">1", TRUE ~ NA_character_)) |> filter(!is.na(log_rate), !is.na(spec_level))
keep <- intersect(tree$tip.label, dat$species)
phy <- keep.tip(tree, keep)
dat <- dat |> filter(species %in% keep)
dat <- dat[match(phy$tip.label, dat$species), , drop = FALSE]
dat <- as.data.frame(dat); rownames(dat) <- dat$species
sink("MiSSE_specialisation_3level.txt")
fit <- phylolm(log_rate ~ factor(spec_level), data = dat, phy = phy, model = "lambda")
summary(fit)
sink()

# Lepidoptera
dat <- combined |>
 mutate(LEPID = ifelse(is.na(LEPID), 0L, as.integer(LEPID))) |>
 filter(!is.na(log_rate))
keep <- intersect(tree$tip.label, dat$species)
phy <- keep.tip(tree, keep)
dat <- dat |> filter(species %in% keep)
dat <- dat[match(phy$tip.label, dat$species), , drop = FALSE]
dat <- as.data.frame(dat); rownames(dat) <- dat$species
dat$LEPID <- factor(dat$LEPID, levels = c(0,1))
table(dat$LEPID)
sink("MiSSE_lepid_binary.txt")
fit <- phylolm(log_rate ~ LEPID, data = dat, phy = phy, model = "lambda")
summary(fit)
sink()

# Hymenoptera
dat <- combined |> mutate(HYMEN = ifelse(is.na(HYMEN), 0L, as.integer(HYMEN))) |> filter(!is.na(log_rate))
keep <- intersect(tree$tip.label, dat$species)
phy <- keep.tip(tree, keep)
dat <- dat |> filter(species %in% keep)
dat <- dat[match(phy$tip.label, dat$species), , drop = FALSE]
dat <- as.data.frame(dat); rownames(dat) <- dat$species
dat$HYMEN <- factor(dat$HYMEN, levels = c(0,1))
table(dat$HYMEN)
sink("MiSSE_hymen_binary.txt")
fit <- phylolm(log_rate ~ HYMEN, data = dat, phy = phy, model = "lambda")
summary(fit)
sink()